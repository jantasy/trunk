package cn.yjt.oa.app.security;

public interface VerifyCodeEncrypt {

	public String encrypt(String verifyCode);
	
}
